param([switch]$Rebuild)
docker compose down -v
if($Rebuild){ docker compose build --no-cache backend } else { docker compose build backend }
docker compose up -d
$tries=0
while($tries -lt 30){
  $status = docker compose ps --format json | ConvertFrom-Json
  $dbStatus = ($status | Where-Object { $_.Service -eq "db" }).State
  if($dbStatus -like "*healthy*"){break}
  Start-Sleep -Seconds 2; $tries++
}
if($tries -ge 30){ throw "DB not healthy" }
docker compose exec backend flask db upgrade
docker compose exec backend python seed.py
Write-Host "Ready -> http://localhost:5000/swagger-ui"
